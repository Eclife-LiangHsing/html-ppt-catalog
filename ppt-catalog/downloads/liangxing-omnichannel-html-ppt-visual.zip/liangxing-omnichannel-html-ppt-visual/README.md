# 良興全通路轉型個案 HTML PPT｜圖文版

此版本加入工研院文章頁面中的代表性圖表，供與文字版比較。

來源：<https://www.if.itri.org.tw/ArticleView.aspx?v=62>
