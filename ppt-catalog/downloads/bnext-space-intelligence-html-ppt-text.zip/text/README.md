# 李飛飛空間智慧｜文字版 HTML PPT

來源：https://www.bnext.com.tw/article/90913/fei-fei-lee-space-intelligence
